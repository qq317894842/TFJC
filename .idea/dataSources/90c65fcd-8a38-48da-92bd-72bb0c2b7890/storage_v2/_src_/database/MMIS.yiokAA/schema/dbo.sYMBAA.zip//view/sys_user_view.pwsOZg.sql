create view sys_user_view 
as
SELECT 
			su.*, [role_name] = stuff(
				(
					SELECT
						',' + [role_name]
					FROM
						sys_user
					LEFT JOIN sys_user_role sur ON sys_user.user_id = sur.user_id
					LEFT JOIN sys_role sr ON sur.role_id = sr.role_id
					WHERE
						su.user_id = sys_user.user_id FOR xml path ('')
				),
				1,
				1,
				''
			)
		FROM
			sys_user su
go

