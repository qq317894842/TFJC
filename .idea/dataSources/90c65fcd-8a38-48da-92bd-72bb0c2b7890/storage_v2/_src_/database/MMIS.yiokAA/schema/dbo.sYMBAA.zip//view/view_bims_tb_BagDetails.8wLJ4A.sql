CREATE VIEW [dbo].[view_bims_tb_BagDetails] AS select ID,BSM,EXED,bagStatusID,ReceiveTime,Origin,DeviceName,memo,ImgUrl,[des] as dess,[status] as statuss,
case when Origin='CheckIn' then '行李('+BSM+')从【'+ISNULL(DeviceName,'')+'】柜台值机' 
when Origin='LowerSecurityCheck' then ( case when ISNULL(DeviceName,'') like 'CT%' then 'BID:【'+ISNULL(BID,'')+'】    行李从【'+ISNULL(DeviceName,'')+'】CT机返回，安检结果：【'+ISNULL(memo,'')+'】' else   'BID:【'+ISNULL(BID,'')+'】    行李经过【'+ISNULL(DeviceName,'')+'】RFID(安检前)' end)
when Origin='Unpacket' then  'BID:【'+ISNULL(BID,'')+'】    行李经过【'+ISNULL(DeviceName,'')+'】分流结果为【'+ISNULL(memo,'')+'】'
when Origin='PackageReport_ScanResult_ICS' then  'BID:【'+ISNULL(BID,'')+'】    行李在【'+ISNULL(DeviceName,'')+'】导入口RFID成功读码'
when Origin='LC' then '行李在【'+ISNULL(DeviceName,'')+'】LC异常'
when Origin='ICSEBS' then ( case when ISNULL(DeviceName,'')='EBSIN' then 'BID:【'+ISNULL(BID,'')+'】    行李从【'+ISNULL(DeviceName,'')+'】进入早到存储' else  'BID:【'+ISNULL(BID,'')+'】    行李从【'+ISNULL(DeviceName,'')+'】出早到存储' end)
when Origin='Tracking_Loading' then 'BID:【'+ISNULL(BID,'')+'】    行李经过【'+ISNULL(DeviceName,'')+'】ICS的装载口'
when Origin='Tracking_PreICS' then 'BID:【'+ISNULL(BID,'')+'】    行李从【'+ISNULL(DeviceName,'')+'】预分拣'
when Origin='Tracking_ICS' then 'BID:【'+ISNULL(BID,'')+'】    行李从【'+ISNULL(DeviceName,'')+'】分拣'
when Origin='Tracking_OutMes' then ( case when ISNULL(DeviceName,'')='MESIN' then 'BID:【'+ISNULL(BID,'')+'】    行李进入人工编码站【'+ISNULL(DeviceName,'')+'】，原因【'+ISNULL(memo,'')+'】' else 'BID:【'+ISNULL(BID,'')+'】    行李出人工编码站【'+ISNULL(DeviceName,'')+'】，原因【'+ISNULL(memo,'')+'】' end)
when Origin='DeRegister_ICS' then  '行李在【'+ISNULL(DeviceName,'')+'】倾翻'
else '' end as Msg,
case when Origin='CheckIn' then 'el-icon-circle-check' 
when Origin='LowerSecurityCheck' then 'el-icon-search'
when Origin='Unpacket' then  'el-icon-sort'
when Origin='PackageReport_ScanResult_ICS' then  'el-icon-bottom-right'
when Origin='PackageReport_StoreResult_ICS' then 'el-icon-s-operation'
when Origin='Tracking_Loading' then  'el-icon-sort-up'
when Origin='Tracking_PreICS' then  'el-icon-sort'
when Origin='Tracking_ICS' then  'el-icon-sort'
when Origin='Tracking_OutMes' then 'el-icon-s-custom'
when Origin='Tracking_ICS' then  'el-icon-finished'
else '' end as icon
from [10.41.253.2\BIDS].BIMS.[DBO].tb_BagDetails
go

