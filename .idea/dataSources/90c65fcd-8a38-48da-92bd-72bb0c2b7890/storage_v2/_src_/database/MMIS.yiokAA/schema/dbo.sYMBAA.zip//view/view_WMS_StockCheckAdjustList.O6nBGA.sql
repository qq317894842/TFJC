CREATE VIEW [dbo].[view_WMS_StockCheckAdjustList] AS select sc.*,wh.WarehouseName from WMS_WM_StockCheck sc
        inner join (select BillNo from WMS_WM_StockCheckDetail where isnull(DiffQuantity,0)!=0 group by BillNo) scd on sc.BillNo=scd.BillNo
        left join WMS_WM_Warehouse wh on sc.WarehouseCode = wh.WarehouseCode
				where sc.user_ext_value1 is null
go

