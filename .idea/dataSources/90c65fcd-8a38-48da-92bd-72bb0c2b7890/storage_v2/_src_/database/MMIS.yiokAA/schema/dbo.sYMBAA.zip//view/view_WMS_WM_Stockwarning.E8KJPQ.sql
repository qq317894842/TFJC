create view view_WMS_WM_Stockwarning as

select 
    CASE when m.MinStockQuty is not null and t.Quantity < isnull(m.MinStockQuty,0) then 'red,库存过小'
		when m.MaxStockQuty is not null and t.Quantity>isnull(m.MaxStockQuty,0) then 'red,库存过大' ELSE '' end
    as bgcolor,
    CASE when t.Quantity < isnull(m.MinStockQuty,0)  then '建议申购'  ELSE
    (CASE when t.Quantity>isnull(m.MaxStockQuty,0)  then '禁止采购'  ELSE '' end)
    END  as suggest,
    h.warehousename as warehousename,m.materialname as materialname ,m.Price as price,
    m.MinStockQuty as minstockquty,m.isminstockwarn as isminstockwarn,m.maxstockquty as maxstockquty,m.IsMaxStockWarn as ismaxstockwarn,b.UnitName as unitname,b.unitcode as unitcode,t.*  from WMS_WM_Stock t left join WMS_WM_Warehouse h 
		on   t.warehousecode=h.warehousecode left join WMS_MM_MaterialInfo m on  t.materialcode=m.materialcode left join WMS_BD_Unit b on   b.UnitCode=t.Unit
go

